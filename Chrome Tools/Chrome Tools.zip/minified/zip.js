const zip = require("node-7z");


var task = new zip();
console.log(task);
task.add("test2.zip","minified")
.catch(function(err) {
	console.error(err);
});