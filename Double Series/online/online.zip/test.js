var deck = [];
var hands = [];
var cardsleft;
var handLength = 7;
var handLengths = [];
createDeck();
newGame();
console.log(hands,deck,deck[cardsleft]);
while(1) {
    drawCard(0,0,0);
}
function createDeck() {
    //creates deck with 4 add Js, 4 remove Js, 4 corner pieces, and 2 of each other card
    for (var i = 2 ; i < 50 ; i++) {
        deck.push(i);
        deck.push(i);
    }
    for (var i = 0 ; i < 4 ; i++) {
        deck.push(1);
        deck.push(0);
        deck.push(-1);
    }
}
//pick up new card, return value of newCard
function drawCard(player,card,team,replace) {
    if (cardsleft > 0) {
        cardsleft--; //0 index
        hands[player][card] = deck[cardsleft];
        console.log(deck[cardsleft]);
        return hands[player][card];
    } else {
        hands[player].splice(card,1);
        handLengths[player]--;
        checkNoCards();
        //returns nothing
    }
}

function newGame() {
    //shuffle(deck);
    cardsleft = 108;
    //4 players
    for (var i = 0 ; i < 4 ; i++) {
        hands[i] = deck.slice(cardsleft - handLength,cardsleft);
        handLengths[i] = handLength;
        cardsleft -= handLength;
    }
    cardsPlayed = [];
}