var helpers = require("./playHelper.js");
var constants = require("../constants");
var getOptions = helpers.getOptions;
var cardOptions = helpers.cardOptions;
var hasAdd = helpers.hasAdd;
var hasRemove = helpers.hasRemove;
var hasOnlyJ = helpers.hasOnlyJ;
var hasOnlyRemoveJ = helpers.hasOnlyRemoveJ;
var addJoptions = helpers.addJoptions;
var removeJoptions = helpers.removeJoptions;
var hasUselessCard = helpers.hasUselessCard;
var addJ = helpers.addJ;
var removeJ = helpers.removeJ;

var board;
var points;
var team;

var possible = [];
var references = [];
var cardsLeft = [];
var totCardsLeft;

probSetup();

exports.play = playProb;
exports.setup = function(info,myTeam) {
    team = myTeam;
    helpers.setup(info);
    board = info.board;
    points = info.points;
};
exports.onPlay = function(play) {
    console.log(play);
    cardsLeft[play.card]--;
    totCardsLeft--;
    if (play.action === constants.PLAY_FINISH) {
        for (var i = 0 ; i < player.finishedLines.length ; i++) {
            updatePosition(player.finishedLines[i]);
        }
    } else {
        updatePosition(play.position);
    }
}
exports.onNewGame = function() {
    //starting at higher # is slightly faster
    for (var i = 49 ; i >= 2 ; i++) {
        cardsLeft[i] = 2;
    }
    cardsLeft[1] = 4;
    cardsLeft[0] = 4;
    cardsLeft[-1] = 4;
    totCardsLeft = 108;
}

function updatePosition(pos) {
    var x = pos[0];
    var y = pos[1];
    //what the place has been turned into
    switch (points[x][y]) {
        case
    }
}

function playProb(hand,team) {

    //update probabilities
    //get best probability
    
}

function probSetup() {
    start(1,1);
    start(1,0);
    start(0,1);
    start(1,-1);
    for (var i = 0 ; i < 10 ; i++) {
        var temp = [];
        for (var j = 0 ; j < 10 ; j++) {
            var temp.push([]);
        }
        references.push(temp);
    }
    for (var i = 0 ; i < possible.length ; i++) {
        var p = possible[i];
        var x = p[0][0];
        var y = p[0][1];
        var dirX = p[1][0];
        var dirY = p[1][1];

        for (var j = 0 ; j < 4 ; j++) {
            references[x + j*dirX][y + j*dirY].push(i);
        }
    }
    /*for (var i = 0 ; i < possible.length ; i++) {
        for (var j = i + 1 ; j < possible.length ; j++) {
            var meet = true;
            var meetPoint;
            if (sameDir(possible[i],possible[j])) {
                var p1 = possible[i];
                var p2 = possible[j];
                if (dirX) {
                    var x1 = p1[0][0];
                    var x2 = p2[0][0];
                    if ((x1 > x2 && x1 + 5 < x2) || (x2 > x1 && x2 + 5 < x1)) {
                        meet = true;
                    } else {
                        meet = false;
                    }
                }
                if (p1[0][0] === )
            } else {

            }
        }
    }*/
}

function sameDir(dir1,dir2) {
    return dir1[0] === dir2[0] && dir1[1] === dir2[1];
}

function isDiag(dir) {
    return dirX && Math.abs(dirY);
}

function start(dirX,dirY) {
    for (var x = 0 ; x < 10 ; x++) {
        for (var y = 0 ; y < 10 ; y++) {
            if (!outOfBounds(x,y) && !outOfBounds(x + 4*dirX,y + 4*dirY)) {
                //
                {
                    position:[x,y],
                    direction:[dirX,dirY],
                    selfP:1,
                    otherP:1,
                    collisions:[]
                }
                possible.push([[x,y],[dirX,dirY],0,0,[]]);
            }
        }
    }
}